<?php
class Product extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');

        $this->load->model('Product_model');
    }

    function index()
    {
        $data['product'] = $this->Product_model->getProduct();
        $this->load->view('list', $data);
    }

    public function form($id = 0)
    {
        $this->load->helper('form');
        //default values are empty if the customer is new
        $data['id']                    = '';
        $data['name']        = '';
        $data['price']                = '';
        $data['category']                = '';
        $data['image']                = '';

        if ($id) {
            $product = $this->Product_model->gettRow($id);

            //if the customer does not exist, redirect them to the customer list with an error
            if (!$product) {
                $this->session->set_flashdata('error', 'The requested course could not be found.');
                redirect('admin/course');
            }

            //set values to db values
            $data['id']         = $product->id;
            $data['name']         = $product->name;
            $data['price']       = $product->price;
            $data['category']       = $product->category;
            $data['image']       = $product->image;
        }

        $config['upload_path'] = 'upload/product/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg|jpe';
        $config['encrypt_name'] = TRUE;
        $this->load->library('upload', $config);

        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<p class="invalid-feedback">', '</p>');
        $this->form_validation->set_rules('name', 'Name', 'trim|required');
        $this->form_validation->set_rules('price', ' Price', 'trim|required');
        $this->form_validation->set_rules('category', ' Category', 'trim|required');

        if ($this->form_validation->run() == FALSE) {
            // $this->load->view('admin/blog/create', $data);
            $this->load->view('create', $data);
        } else {

            if (!empty($_FILES['image']['name'])) {

                if ($this->upload->do_upload('image')) {
                    $image = $this->upload->data();
                    $formArray['image'] = $image['file_name'];

                    $formArray['id'] = $id;
                    $formArray['name'] = $this->input->post('name');
                    $formArray['price'] = $this->input->post('price');
                    $formArray['category'] = $this->input->post('category');

                    $this->Product_model->create($formArray);

                    $oldimage = $this->input->post('old_image');

                    if (file_exists('upload/product/' . $oldimage)) {
                        unlink('upload/product/' . $oldimage);
                    }
                    if ($id) {
                        $this->session->set_flashdata('message', 'product has updated successfully');
                    } else {
                        $this->session->set_flashdata('message', 'product has added successfully');
                    }
                    redirect('product');
                }
            }

            $formArray['id'] = $id;
            $formArray['name'] = $this->input->post('name');
            $formArray['price'] = $this->input->post('price');
            $formArray['category'] = $this->input->post('category');

            $this->Product_model->create($formArray);

            if ($id) {
                $this->session->set_flashdata('message', 'Product has updated successfully');
            } else {
                $this->session->set_flashdata('message', 'Product has added successfully');
            }
            redirect('product');
        }
    }


    function delete($id)
    {
        $product = $this->Product_model->gettRow($id);
        if (empty($product)) {
            $this->session->set_flashdata('error', 'Product Not Found');
            redirect('product');
        }
        if (file_exists('product' . $product->image)) {
            unlink('upload/product/' . $product->image);
        }

        $this->Product_model->deleteRow($id);

        $this->session->set_flashdata('success', 'Product Deleted Successfully');
        redirect('product');
    }
}
