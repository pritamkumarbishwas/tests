<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Api extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('api_model');
        $this->load->library('form_validation');
    }

    function index()
    {
        $data = $this->api_model->fetch_all();
        echo json_encode($data->result_array());
    }

    function insert()
    {
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('price', 'Price', 'required');
        $this->form_validation->set_rules('category', 'Category', 'required');
        if ($this->form_validation->run()) {
            $data = array(
                'name'    =>    $this->input->post('name'),
                'price'        =>    $this->input->post('price'),
                'category'        =>    $this->input->post('category')
            );

            $this->api_model->insert_api($data);

            $array = array(
                'status' => 0,
                'data' => 'Product details',
                'Data add success' => true
            );
        } else {
            $array = array(
                'error'                    =>    true,
                'name_error'        =>    form_error('name'),
                'price_error'        =>    form_error('price'),
                'category_error'        =>    form_error('category')
            );
        }
        echo json_encode($array);
    }

    function fetch_single($id = 0)
    {
        $data = $this->api_model->fetch_single_user($id);

        foreach ($data as $row) {
            $output['id'] = $row['id'];
            $output['name'] = $row['name'];
            $output['price'] = $row['price'];
            $output['category'] = $row['category'];
            $output['image'] = $row['image'];
        }
        echo json_encode($output);
    }

    function update($id = 0)
    {
        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('price', 'Price', 'required');
        $this->form_validation->set_rules('category', 'Category', 'required');
        if ($this->form_validation->run()) {
            $data = array(
                'name'    =>    $this->input->post('name'),
                'price'        =>    $this->input->post('price'),
                'category'        =>    $this->input->post('category')
            );

            $this->api_model->update_api($id, $data);
            

            $array = array(
                'status' => 0,
                'data' => 'Product details',
                'Data update success'        =>    true
            );
        } else {
            $array = array(
                'error'                    =>    true,
                'name_error'        =>    form_error('name'),
                'price_error'        =>    form_error('price'),
                'category_error'        =>    form_error('category')
            );
        }
        echo json_encode($array);
    }

    function delete($id = 0)
    {
        if ($this->api_model->delete_single_user($id)) {
            $array = array(

                'Data delete success'    =>    true
            );
        } else {
            $array = array(
                'error'        =>    true
            );
        }
        echo json_encode($array);
    }
}
