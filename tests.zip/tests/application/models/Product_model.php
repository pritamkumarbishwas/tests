<?php defined('BASEPATH') or exit('No direct script access allowed');

class Product_model extends CI_Model
{

	public function create($formArray)
	{
		if ($formArray['id']) {
			$this->db->where('id', $formArray['id']);
			$this->db->update('products', $formArray);
			return $formArray['id'];
		} else {

			$this->db->insert('products', $formArray);
			return $this->db->insert_id();
		}
	}

	public function getProduct()
	{
		$this->db->order_by('id', 'DESC');
		return $this->db->get('products')->result_array();
	}

    public function gettRow($id)
	{
		$this->db->where('id', $id);
		$products = $this->db->get('products')->row();
		return $products;
	}

    public function deleteRow($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('products');
	}
}
