<footer class="main-footer ">
  <strong>Copyright &copy; 2022-2025 <a href="http://funceptseduventure/ ">test</a>.</strong>
  All rights reserved.
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark ">
  <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="<?= base_url() ?>public/admin/plugins/jquery/jquery.min.js "></script>
<!-- jQuery UI 1.11.4 -->
<script src="<?= base_url() ?>public/admin/plugins/jquery-ui/jquery-ui.min.js "></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->

<!-- Bootstrap 4 -->
<script src="<?= base_url() ?>public/admin/plugins/bootstrap/js/bootstrap.bundle.min.js "></script>
<!-- ChartJS -->
<script src="<?= base_url() ?>public/admin/plugins/chart.js/Chart.min.js "></script>
<!-- Sparkline -->
<script src="<?= base_url() ?>public/admin/plugins/sparklines/sparkline.js "></script>
<!-- JQVMap -->
<script src="<?= base_url() ?>public/admin/plugins/jqvmap/jquery.vmap.min.js "></script>
<script src="<?= base_url() ?>public/admin/plugins/jqvmap/maps/jquery.vmap.usa.js "></script>
<!-- jQuery Knob Chart -->
<script src="<?= base_url() ?>public/admin/plugins/jquery-knob/jquery.knob.min.js "></script>
<!-- daterangepicker -->
<script src="<?= base_url() ?>public/admin/plugins/moment/moment.min.js "></script>
<script src="<?= base_url() ?>public/admin/plugins/daterangepicker/daterangepicker.js "></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?= base_url() ?>public/admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js "></script>
<!-- Summernote -->
<script src="<?= base_url() ?>public/admin/plugins/summernote/summernote-bs4.min.js "></script>
<!-- overlayScrollbars -->
<script src="<?= base_url() ?>public/admin/plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js "></script>
<!-- AdminLTE App -->
<script src="<?= base_url() ?>public/admin/dist/js/adminlte.js "></script>
<!-- AdminLTE for demo purposes -->
<script src="<?= base_url() ?>public/admin/dist/js/demo.js "></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?= base_url() ?>public/admin/dist/js/pages/dashboard.js "></script>
<!-- DataTables  & Plugins -->
<script src="<?= base_url() ?>public/admin/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>public/admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?= base_url() ?>public/admin/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?= base_url() ?>public/admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?= base_url() ?>public/admin/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?= base_url() ?>public/admin/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?= base_url() ?>public/admin/plugins/jszip/jszip.min.js"></script>
<script src="<?= base_url() ?>public/admin/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?= base_url() ?>public/admin/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?= base_url() ?>public/admin/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?= base_url() ?>public/admin/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?= base_url() ?>public/admin/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">

<script>
  $(function() {
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>

<script>
function deleteData(url){
      swal({
        title: "Are you sure?",
        text: "But you will still be able to retrieve this file.",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes,Delete it!",
        cancelButtonText: "No, cancel please!",
        closeOnConfirm: false,
        closeOnCancel: false
      },
      function(isConfirm) {
        if (isConfirm) {
          swal('Archived!','Click ok to see!','success');
          window.location.href=url;
        } else {
          swal("Cancelled","Your imaginary file is safe :)", "error");
        }
      });
      }
  
</script>
</body>

</html>