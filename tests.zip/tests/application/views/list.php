<?php $this->load->view('header'); ?>
<?php $this->load->view('sidebar'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Product List <small style="font-size:16px;">Admin panel</small></h1>
                </div>

            </div>
        </div>
        <!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

        <?php
        //lets have the flashdata overright "$message" if it exists
        if ($this->session->flashdata('message')) {
            $message    = $this->session->flashdata('message');
        }

        if ($this->session->flashdata('error')) {
            $error  = $this->session->flashdata('error');
        }

        if (function_exists('validation_errors') && validation_errors() != '') {
            $error  = validation_errors();
        }
        ?>

        <div id="js_error_container" class="alert alert-danger" style="display:none;">
            <p id="js_error"></p>
        </div>

        <div id="js_note_container" class="alert alert-info" style="display:none;">

        </div>

        <?php if (!empty($message)) : ?>
            <div class="alert alert-success">
                <a class="close" data-dismiss="alert">×</a>
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($error)) : ?>
            <div class="alert alert-danger">
                <a class="close" data-dismiss="alert">×</a>
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- /.card -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Display All Product </h3>
                            <a href="<?= base_url() . 'product/form' ?>" class="btn btn-sm float-right " style="background:#367fa9;color: white;"><i class="fa fa-plus"></i> Add New Product</a>

                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table id="example2" class="table table-bordered table-hover">
                                <thead style="background:#367fa9;color: white;">
                                    <tr>
                                        <th>S.No.</th>
                                        <th>name</th>
                                        <th>price</th>
                                        <th>category</th>
                                        <th>image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if (!empty($product)) {
                                        $sno = 1;
                                        foreach ($product as $row) {

                                    ?>
                                            <tr>
                                                <td><?php echo $sno; ?></td>
                                                <td><?php echo $row['name'] ?></td>
                                                <td><?php echo  $row['price'] ?></td>
                                                <td><?php echo  $row['category'] ?></td>
                                                <td>
                                                    <img src="<?php echo base_url() . 'upload/product/' . $row['image']; ?>" class="img-square img-responsive" style="width:100px;height:auto">
                                                </td>

                                                <td>
                                                    <a href="<?= base_url() . 'product/form/' . $row['id']; ?>" class="btn btn-primary btn-sm"><i class="fas fa-edit"></i> Edit</a>
                                                    <a href="#" onclick="deleteData('<?= base_url() . 'product/delete/' . $row['id'] ?>')" class="btn btn-danger btn-sm"><i class="fas fa-trash-alt"></i> Delete</a>

                                                </td>
                                            </tr>
                                        <?php
                                            $sno++;
                                        }
                                    } else { ?>
                                        <tr>
                                            <td colspan="4">Record Not Found</td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php $this->load->view('footer'); ?>