<?php $this->load->view('header'); ?>
<?php $this->load->view('sidebar'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1> Products <small style="font-size:16px;">Products</small></h1>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-primary">
                    <div class="card-header" style="background: #3c8dbc;color:white;">
                        <h3 class="card-title"> Products Form</h3>
                    </div>
                    <form id="topic_form" name="topic_form" method="post" enctype="multipart/form-data" action="<?= base_url() . 'product/form/'.$id; ?>">
                        <div class="card-body">
                            <?php if($id){?>
                            <div class="form-group">
                                <label for="">Product Image</label>
                                <div class="form-control" id="imgProfile_upload" style="border: 1px solid #ddd;width:180px; height:140px;margin-top:5px;">
                                    <img src="<?php echo base_url() . 'upload/product/' . $image;?>" class="img-square img-responsive" style="background-size: cover;width:100%;height:100%">
                                </div>
                            </div>
                            <?php } ?>
                            <div class="form-group">
                                <label for="title">Name</label>
                                <input class="form-control <?= (form_error('name') != '') ? 'is-invalid' : ''; ?>" type="text" name="name" placeholder="name" value="<?= set_value('name',$name); ?>">
                                <?php echo form_error('name') ?>
                            </div>

                            <div class="form-group">
                                <label for="title">Price</label>
                                <input class="form-control <?= (form_error('price') != '') ? 'is-invalid' : ''; ?>" type="text" name="price" placeholder="price" value="<?= set_value('price',$price); ?>">
                                <?php echo form_error('price') ?>
                            </div>

                            <div class="form-group">
                                <label for="title">Category</label>
                                <input class="form-control <?= (form_error('category') != '') ? 'is-invalid' : ''; ?>" type="text" name="category" placeholder="category" value="<?= set_value('category',$category); ?>">
                                <?php echo form_error('category') ?>
                            </div>
                            
                            <div class="form-group">
                                <label for="image">Image </label>
                                <input class="form-control <?= (form_error('old_image') != '') ? 'is-invalid' : ''; ?>" type="hidden" name="old_image" id="old_image" placeholder="old_image" value="<?= set_value('old_image',$image); ?>">
                                <input class="form-control <?= (form_error('image') != '') ? 'is-invalid' : ''; ?>" type="file" name="image" id="image" placeholder="image" value="<?= set_value('image'); ?>">
                                <?php echo form_error('image') ?>
                            </div>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary" style="background: #3c8dbc;color:white;">Save</button>
                            <a href="<?= base_url() . 'product' ?>" class="btn float-right" style="background: #3c8dbc;color:white;">Back</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- /.Left col -->


    <!-- /.content -->
</div>

<?php $this->load->view('footer'); ?>